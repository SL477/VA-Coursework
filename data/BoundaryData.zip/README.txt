Files:
england_gor_2011.shp
england_gor_2011.shx
england_gor_2011.dbf
england_gor_2011.prj

Areas:
East Midlands
East of England
London
North East
North West
South East
South West
West Midlands
Yorkshire and The Humber

This data is provided with the support of the ESRC and JISC and uses boundary material which is copyright of the Crown, the Post Office and the ED-LINE consortium.